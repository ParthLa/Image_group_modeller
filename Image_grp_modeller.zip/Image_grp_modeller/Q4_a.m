clc;
clear;
a=load("../data/mnist.mat");
ltest=a.labels_test;
ltrain=a.labels_train;
dtest=a.digits_test;
dtrain=a.digits_train;
l1=length(ltrain);

M=zeros(28,28);
%Edig={M,M,M,M,M,M,M,M,M,M};
Edig=repmat(M,10,1);
cntdig=zeros(10,1);
for i=1:l1
    digit=ltrain(i);
    index=digit+1;
    T=dtrain(:,:,i);
    cntdig(index)=cntdig(index)+1;
    rowl=28*(index-1)+1;
    rowr=28*index;
    Edig(rowl:rowr,:)=Edig(rowl:rowr,:)+double(T);
end    
for i=1:10
    rowl=28*(i-1)+1;
    rowr=28*i;
    Edig(rowl:rowr,:)=Edig(rowl:rowr,:)/cntdig(i);
end
E0=Edig(1:28,:);
E1=Edig(29:56,:);
E2=Edig(57:84,:);
E3=Edig(85:112,:);
E4=Edig(113:140,:);
E5=Edig(141:168,:);
E6=Edig(169:196,:);
E7=Edig(197:224,:);
E8=Edig(225:252,:);
E9=Edig(253:280,:);
%[E0,E1,E2,E3,E4,E5,E6,E7,E8,E9]=Edig{:}; %mean matrices of all digits
