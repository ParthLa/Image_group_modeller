N=input("");
cnt=0;
for i=1:N
    x1=rand(1,1)*2-1;
    x2=rand(1,1)*2-1;
    %key={x1};
    %val={x2};
    %o=containers.Map(key,val);
    if (x1^2) + (x2^2)<=1
            cnt=cnt+1;
    end
end
disp(cnt*4/N);