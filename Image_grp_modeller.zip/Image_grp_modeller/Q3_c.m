clc;
clear;
a=load('../data/points2D_Set2.mat'); %loading the data points from the file 
x=a.x;
y=a.y;
scatter(x,y); %plotting the scatter plot of x and y
lx=length(x); %length of the vector
ly=length(y);
sumxy=0;
sumx=0;
sumx2=0;
sumy=0;
sumy2=0;
for i=1:lx %finding sum of xi*yi
    sumxy=sumxy+x(i)*y(i);
end

for i=1:lx
    sumx=sumx+x(i);
    sumx2=sumx2+x(i)*x(i);
end

for j=1:ly
    sumy=sumy+y(j);
    sumy2=sumy2+(y(j)*y(j));
end

Ex=sumx/lx; %mean(x)
Ey=sumy/ly; %mean(y)
Exy=sumxy/lx;
Ex2=sumx2/lx;
Ey2=sumy2/ly;
Varx=Ex2-(Ex*Ex); %variance(x)
Vary=Ey2-(Ey*Ey); %variance(y)
Cxy=Exy-(Ex*Ey); 
C = [Varx,Cxy;Cxy,Vary]; %C = Covariance Matrix

[V,D] = eig(C); %obtaining the required eigen values and eigen vectors
dim=size(C,1);
maxeig_i=1; %to find index corresponding to max eigen value
maxval=D(1,1);
for i=1:dim
    if(D(i,i)>maxval)
        maxeig_i=i;
        maxval=D(i,i);
    end
end

ev=V(:,i);
m=ev(2)/ev(1); %slope of the required line 
x1=linspace(-2,2,600);
c1=Ey-m*Ex; %y-intercept of the required line
y1=m*x1+c1;
hold on;
plot(x1,y1);%plotting the required line on the same figure of scatter plot using hold on

