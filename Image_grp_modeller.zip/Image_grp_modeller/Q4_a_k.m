 a=load("../data/mnist.mat");
 dtr=a.digits_train;
 dte=a.digits_test;
 ltr=a.labels_train;
 lte=a.labels_test;
 MEAN=zeros(784,1,10);
 COUNT=zeros(1,10);
 COV=zeros(784,784,10);% respective slices store the covariances
%  for i=0:9
%      MEAN=zeros(784,1);
%      VAR=zeros(784,784);
%      COUNT=0;
for j=1:60000
    j;
    i = ltr(j);
    DUMMY=dtr(:,:,j);
    IMG=reshape(DUMMY,784,1);
    IMGD=double(IMG);%image vector
    MEAN(:,:,i+1)=MEAN(:,:,i+1)+IMGD;
    COUNT(:,i+1)=COUNT(:,i+1)+1;
    IMGDT=transpose(IMGD);%transpose of image vector
    PROD=IMGD*IMGDT;
    COV(:,:,i+1)=COV(:,:,i+1)+PROD;
end

for i=1:10
    MEAN(:,:,i)=MEAN(:,:,i)/COUNT(:,i);
    MEAN1=uint8(MEAN(:,:,i));
    IMGSHOW=reshape(MEAN1,28,28);
    imshow(IMGSHOW);
    pause(5);
end


